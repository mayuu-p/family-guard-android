# Android configuration

In `android/app/src/main/AndroidManifest.xml`, inside `<manifest>` and before
`<application>`, add the permissions required by the features you actually ship:

```xml
<uses-permission android:name="android.permission.INTERNET" />
<uses-permission android:name="android.permission.ACCESS_COARSE_LOCATION" />
<uses-permission android:name="android.permission.ACCESS_FINE_LOCATION" />
<uses-permission android:name="android.permission.POST_NOTIFICATIONS" />
```

For a production background-location implementation, review the current Android
foreground-service type requirements and Play policy. Do not add background
permissions until you have implemented a visible, user-started foreground service
and a clear in-app disclosure. Android 10+ background location and Android 13+
notification permission have separate runtime flows.

Google Maps:
```xml
<meta-data android:name="com.google.android.geo.API_KEY"
           android:value="YOUR_ANDROID_MAPS_KEY"/>
```
Place this inside `<application>`. Restrict the key by Android package name and
SHA-1 signing certificate. Do not commit production keys to a public repository.
