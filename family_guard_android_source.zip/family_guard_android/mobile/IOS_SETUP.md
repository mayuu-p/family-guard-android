# iOS configuration

Add clear purpose strings to `ios/Runner/Info.plist`:
```xml
<key>NSLocationWhenInUseUsageDescription</key>
<string>Your location is shared with your linked parent when you enable sharing.</string>
```

For a future background-location release, configure the Location Updates background
mode and the appropriate Always authorization flow only after implementing a visible
consent and revocation experience. iOS can suspend apps and does not guarantee a
30-second update cadence.

Configure the Google Maps iOS SDK key in the iOS app entry point using the current
google_maps_flutter setup guide. Restrict the key to the iOS bundle identifier.
