# Android platform implementation requirements

This document is deliberately not a recipe for covert capture.

## Location
- Request foreground location permission in context.
- If background location is a real product requirement, separately explain why,
  request the platform's background permission through its official flow, and
  run a user-started foreground service with a persistent notification.
- Respect revocation and service stop actions immediately.
- Android may throttle updates and users / OS can stop the service.

## Camera and microphone
- Request CAMERA / RECORD_AUDIO only when a user starts or accepts a video/audio call.
- Show a visible in-app active-call UI and provide mute, camera-off and end controls.
- Stop capture immediately on hang-up, permission revocation or app/session failure.

## Screen sharing
- Use Android MediaProjection. The user must initiate the share and approve the
  system capture prompt. Do not attempt to reuse a previous MediaProjection token
  as lifetime authorization. Current Android releases apply consent and session
  restrictions; follow the SDK version's official requirements.
- Show a persistent/visible sharing state and a prominent Stop Sharing action.
- Handle MediaProjection.Callback.onStop and stop the stream on callback.
- Never capture while no active user-approved session exists.

## Manifest permissions (only as needed)
```xml
<uses-permission android:name="android.permission.INTERNET" />
<uses-permission android:name="android.permission.ACCESS_COARSE_LOCATION" />
<uses-permission android:name="android.permission.ACCESS_FINE_LOCATION" />
<uses-permission android:name="android.permission.CAMERA" />
<uses-permission android:name="android.permission.RECORD_AUDIO" />
<uses-permission android:name="android.permission.POST_NOTIFICATIONS" />
```
Background location and foreground-service permissions must be added only with
the actual service implementation and the target Android SDK / Play policy in mind.
Do not declare permissions for features that are not implemented.
