import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:socket_io_client/socket_io_client.dart' as io;

/// API and signalling-event client only. It does not access camera, microphone,
/// screen pixels or location. Capture must be started separately by a visible,
/// user-initiated platform flow after OS approval.
class CommunicationClient {
  CommunicationClient({
    required this.baseUrl,
    required this.token,
  });

  final String baseUrl;
  final String token;
  io.Socket? _socket;

  Map<String, String> get _headers => {
    'Authorization': 'Bearer $token',
    'Content-Type': 'application/json',
  };

  Future<Map<String, dynamic>> _post(
    String path,
    Map<String, dynamic> body,
  ) async {
    final response = await http.post(
      Uri.parse('$baseUrl$path'),
      headers: _headers,
      body: jsonEncode(body),
    );
    final decoded = response.body.isEmpty
        ? <String, dynamic>{}
        : jsonDecode(response.body) as Map<String, dynamic>;
    if (response.statusCode < 200 || response.statusCode >= 300) {
      throw Exception(decoded['error'] ?? 'Request failed');
    }
    return decoded;
  }

  Future<List<dynamic>> getIncomingRequests() async {
    final response = await http.get(
      Uri.parse('$baseUrl/api/communication/incoming'),
      headers: _headers,
    );
    final decoded = jsonDecode(response.body) as Map<String, dynamic>;
    if (response.statusCode != 200) {
      throw Exception(decoded['error'] ?? 'Could not load requests');
    }
    return decoded['requests'] as List<dynamic>? ?? [];
  }

  Future<Map<String, dynamic>> requestFromParent(String kind) =>
      _post('/api/communication/requests', {'kind': kind});

  Future<Map<String, dynamic>> respondToRequest(
    String requestId, {
    required bool accept,
  }) =>
      _post('/api/communication/requests/$requestId/respond', {
        'accept': accept,
      });

  Future<Map<String, dynamic>> endSession(String sessionId) =>
      _post('/api/communication/sessions/$sessionId/end', {});

  void connect({
    required void Function(Map<String, dynamic>) onLocation,
    required void Function(Map<String, dynamic>) onRequest,
    required void Function(Map<String, dynamic>) onSessionEnded,
  }) {
    _socket = io.io(
      baseUrl,
      io.OptionBuilder()
          .setTransports(['websocket'])
          .setAuth({'token': token})
          .disableAutoConnect()
          .build(),
    );
    _socket!
      ..on('location:update', (data) => onLocation(Map<String, dynamic>.from(data)))
      ..on('communication:request', (data) => onRequest(Map<String, dynamic>.from(data)))
      ..on('communication:ended', (data) => onSessionEnded(Map<String, dynamic>.from(data)))
      ..connect();
  }

  void dispose() {
    _socket?.dispose();
    _socket = null;
  }
}
