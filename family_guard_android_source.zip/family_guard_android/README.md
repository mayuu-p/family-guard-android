# Family Guard — combined Android source bundle

This combines the original Flutter + Express + PostgreSQL starter with the
real-time Socket.IO backend and communication-session API.

## Important: this is SOURCE CODE, not an installable APK
It has not been compiled or device-tested in this environment. It is a
consent-based starter, not a finished production family-monitoring product.

## Android build
You need a computer with Flutter SDK, Android SDK/platform tools, and Java
installed. From the `mobile` folder:

```bash
flutter doctor
flutter pub get
flutter run
```

To build an APK after configuring and testing the app:

```bash
flutter build apk --release
```

The APK is normally produced at:
`mobile/build/app/outputs/flutter-apk/app-release.apk`

## Backend setup
1. Create a PostgreSQL database.
2. Run `database/schema.sql`.
3. Run `backend/migrations/002_communication_and_realtime.sql`.
4. Copy `backend/.env.example` to `backend/.env` and fill in real values.
5. From `backend`, run `npm install` and `npm start`.

Deploy the API to a public HTTPS host before connecting a phone outside your
local network. Set the Flutter app's API base URL to that deployed endpoint
where indicated in `mobile/lib/main.dart`.

## Current scope and limitations
- Includes starter login/family pairing, location, SOS/check-in/geofence
  endpoints and a basic Flutter UI.
- Includes authenticated Socket.IO family-room events and a communication
  request/accept/reject/end API.
- `communication_client.dart` is a client helper; it is not yet wired into a
  complete call/screen-share UI.
- Actual camera/microphone/video calling and screen broadcast are NOT
  implemented. They require WebRTC plus Android MediaProjection and explicit
  Android system approval. No hidden capture or permission bypass is included.
- Background location requires a visible, user-understandable foreground
  service/notification and correct Android manifest/runtime permission flow;
  this starter's periodic foreground flow is not a substitute for a tested
  native background service.
- FCM device-token registration and end-to-end push notification setup remain
  to be completed.
- Add production-grade account recovery, refresh-token rotation, MFA, privacy
  controls, data deletion/retention, tests and security review before release.

See `mobile/ANDROID_SETUP.md`, `mobile/ANDROID_PLATFORM_PERMISSIONS.md`, and
`deploy/DEPLOYMENT.md` for setup notes.
