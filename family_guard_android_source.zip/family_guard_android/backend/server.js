import 'dotenv/config';
import express from 'express';
import http from 'node:http';
import cors from 'cors';
import helmet from 'helmet';
import rateLimit from 'express-rate-limit';
import jwt from 'jsonwebtoken';
import pg from 'pg';
import { z } from 'zod';
import { Server } from 'socket.io';

const { Pool } = pg;
const pool = new Pool({ connectionString: process.env.DATABASE_URL });
if (!process.env.JWT_SECRET || process.env.JWT_SECRET.length < 32) {
  throw new Error('Set JWT_SECRET to at least 32 characters');
}

const app = express();
const server = http.createServer(app);
const allowedOrigins = (process.env.CORS_ORIGIN || '').split(',').filter(Boolean);
app.use(helmet());
app.use(cors({ origin: allowedOrigins.length ? allowedOrigins : false }));
app.use(express.json({ limit: '32kb' }));
app.use('/api', rateLimit({ windowMs: 60_000, limit: 100 }));

const io = new Server(server, {
  cors: { origin: allowedOrigins.length ? allowedOrigins : false },
  transports: ['websocket']
});

const wrap = fn => (req,res,next) => Promise.resolve(fn(req,res,next)).catch(next);
const fail = (res, status, error) => res.status(status).json({ error });
async function getUser(token) {
  const p = jwt.verify(token, process.env.JWT_SECRET, {
    issuer: 'family-safety-api', audience: 'family-safety-app'
  });
  const r = await pool.query('SELECT id,email,display_name,role FROM users WHERE id=$1',[p.sub]);
  return r.rows[0] || null;
}
const auth = wrap(async (req,res,next) => {
  const token = req.headers.authorization?.startsWith('Bearer ')
    ? req.headers.authorization.slice(7) : null;
  if (!token) return fail(res,401,'Authentication required');
  try {
    req.user = await getUser(token);
    if (!req.user) return fail(res,401,'Account not found');
    next();
  } catch { return fail(res,401,'Invalid or expired token'); }
});
const role = expected => (req,res,next) =>
  req.user.role === expected ? next() : fail(res,403,'Forbidden');
async function familyForUser(userId) {
  const r = await pool.query(
    `SELECT id,parent_user_id,child_user_id,sharing_enabled
     FROM family_links WHERE parent_user_id=$1 OR child_user_id=$1 LIMIT 1`,[userId]);
  return r.rows[0] || null;
}
function roomFor(linkId) { return `family:${linkId}`; }
function emitFamily(linkId,event,payload) { io.to(roomFor(linkId)).emit(event,payload); }

io.use(async (socket,next) => {
  try {
    const token = socket.handshake.auth?.token;
    if (!token) return next(new Error('unauthorized'));
    const user = await getUser(token);
    if (!user) return next(new Error('unauthorized'));
    socket.data.user = user;
    next();
  } catch { next(new Error('unauthorized')); }
});
io.on('connection', async socket => {
  const link = await familyForUser(socket.data.user.id);
  if (!link) return;
  // Server derives the room from the authenticated user; client cannot choose a family room.
  socket.join(roomFor(link.id));
  socket.emit('connection:ready', { connected: true });
});

app.get('/health',(_req,res)=>res.json({ok:true}));

// Child submits location only while explicit sharing consent remains enabled.
app.post('/api/location',auth,role('child'),wrap(async(req,res)=>{
  const parsed = z.object({
    latitude:z.number().min(-90).max(90),
    longitude:z.number().min(-180).max(180),
    accuracyM:z.number().min(0).max(100000).optional(),
    batteryLevel:z.number().int().min(0).max(100).optional(),
    recordedAt:z.string().datetime()
  }).safeParse(req.body);
  if (!parsed.success) return fail(res,400,'Invalid location payload');
  const link = await pool.query(
    'SELECT id,sharing_enabled FROM family_links WHERE child_user_id=$1',[req.user.id]);
  if (!link.rowCount || !link.rows[0].sharing_enabled)
    return fail(res,403,'Location sharing is paused or not authorized');
  const p=parsed.data;
  await pool.query(
    `INSERT INTO location_logs(child_user_id,latitude,longitude,accuracy_m,battery_level,recorded_at)
     VALUES($1,$2,$3,$4,$5,$6)`,
    [req.user.id,p.latitude,p.longitude,p.accuracyM??null,p.batteryLevel??null,p.recordedAt]);
  const update={latitude:p.latitude,longitude:p.longitude,accuracyM:p.accuracyM??null,
    batteryLevel:p.batteryLevel??null,recordedAt:p.recordedAt};
  emitFamily(link.rows[0].id,'location:update',update);
  res.status(201).json({ok:true});
}));

// Parent creates a request. This does not activate device sensors.
app.post('/api/communication/requests',auth,role('parent'),wrap(async(req,res)=>{
  const p=z.object({kind:z.enum(['audio_call','video_call','screen_share'])}).safeParse(req.body);
  if(!p.success)return fail(res,400,'Invalid communication type');
  const link=await pool.query(
    `SELECT id,child_user_id FROM family_links WHERE parent_user_id=$1`,[req.user.id]);
  if(!link.rowCount)return fail(res,404,'No linked child');
  const r=await pool.query(
    `INSERT INTO communication_requests(family_link_id,requester_user_id,recipient_user_id,kind)
     VALUES($1,$2,$3,$4) RETURNING id,kind,status,requested_at,expires_at`,
    [link.rows[0].id,req.user.id,link.rows[0].child_user_id,p.data.kind]);
  emitFamily(link.rows[0].id,'communication:request',r.rows[0]);
  res.status(201).json({request:r.rows[0]});
}));

// Child lists only requests addressed to their own account.
app.get('/api/communication/incoming',auth,role('child'),wrap(async(req,res)=>{
  const r=await pool.query(
    `SELECT id,kind,status,requested_at,expires_at FROM communication_requests
     WHERE recipient_user_id=$1 AND status='pending' AND expires_at>now()
     ORDER BY requested_at DESC`,[req.user.id]);
  res.json({requests:r.rows});
}));

app.post('/api/communication/requests/:id/respond',auth,role('child'),wrap(async(req,res)=>{
  const p=z.object({accept:z.boolean()}).safeParse(req.body);
  if(!p.success)return fail(res,400,'accept must be boolean');
  const client=await pool.connect();
  try {
    await client.query('BEGIN');
    const r=await client.query(
      `SELECT * FROM communication_requests
       WHERE id=$1 AND recipient_user_id=$2 AND status='pending' AND expires_at>now()
       FOR UPDATE`,[req.params.id,req.user.id]);
    if(!r.rowCount){await client.query('ROLLBACK');return fail(res,404,'Request expired or unavailable');}
    const request=r.rows[0];
    if(!p.data.accept){
      await client.query(`UPDATE communication_requests SET status='rejected',responded_at=now() WHERE id=$1`,[request.id]);
      await client.query('COMMIT');
      emitFamily(request.family_link_id,'communication:rejected',{requestId:request.id});
      return res.json({status:'rejected'});
    }
    await client.query(`UPDATE communication_requests SET status='accepted',responded_at=now() WHERE id=$1`,[request.id]);
    const session=await client.query(
      `INSERT INTO communication_sessions(request_id,family_link_id,kind)
       VALUES($1,$2,$3) RETURNING id,kind,status,started_at`,
      [request.id,request.family_link_id,request.kind]);
    await client.query(
      `INSERT INTO session_consent_events(session_id,user_id,action)
       VALUES($1,$2,'accepted')`,[session.rows[0].id,req.user.id]);
    await client.query('COMMIT');
    emitFamily(request.family_link_id,'communication:accepted',{requestId:request.id,session:session.rows[0]});
    res.json({session:session.rows[0]});
  } catch(e){await client.query('ROLLBACK');throw e;}
  finally{client.release();}
}));

app.post('/api/communication/sessions/:id/end',auth,wrap(async(req,res)=>{
  const client=await pool.connect();
  try{
    await client.query('BEGIN');
    const r=await client.query(
      `SELECT s.*,fl.parent_user_id,fl.child_user_id
       FROM communication_sessions s JOIN family_links fl ON fl.id=s.family_link_id
       WHERE s.id=$1 FOR UPDATE`,[req.params.id]);
    if(!r.rowCount){await client.query('ROLLBACK');return fail(res,404,'Session not found');}
    const s=r.rows[0];
    if (![s.parent_user_id,s.child_user_id].includes(req.user.id)){
      await client.query('ROLLBACK');return fail(res,403,'Not a session participant');
    }
    if(s.status==='active'){
      await client.query(`UPDATE communication_sessions SET status='ended',ended_at=now(),ended_by=$1 WHERE id=$2`,
        [req.user.id,s.id]);
      await client.query(`UPDATE communication_requests SET status='ended' WHERE id=$1`,[s.request_id]);
      await client.query(`INSERT INTO session_consent_events(session_id,user_id,action) VALUES($1,$2,'ended')`,
        [s.id,req.user.id]);
    }
    await client.query('COMMIT');
    emitFamily(s.family_link_id,'communication:ended',{sessionId:s.id,endedBy:req.user.id});
    res.json({status:'ended'});
  }catch(e){await client.query('ROLLBACK');throw e;}
  finally{client.release();}
}));

app.use((err,_req,res,_next)=>{console.error(err);res.status(500).json({error:'Internal server error'});});
const port=Number(process.env.PORT||3000);
server.listen(port,()=>console.log(`Family Guard API + Socket.IO listening on ${port}`));
