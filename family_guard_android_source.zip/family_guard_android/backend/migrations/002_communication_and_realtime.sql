CREATE TABLE IF NOT EXISTS communication_requests (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  family_link_id UUID NOT NULL REFERENCES family_links(id) ON DELETE CASCADE,
  requester_user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  recipient_user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  kind TEXT NOT NULL CHECK (kind IN ('audio_call','video_call','screen_share')),
  status TEXT NOT NULL DEFAULT 'pending'
    CHECK (status IN ('pending','accepted','rejected','cancelled','expired','ended')),
  requested_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  expires_at TIMESTAMPTZ NOT NULL DEFAULT now() + interval '2 minutes',
  responded_at TIMESTAMPTZ,
  CHECK (requester_user_id <> recipient_user_id)
);
CREATE INDEX IF NOT EXISTS idx_comm_requests_recipient
  ON communication_requests(recipient_user_id, status, requested_at DESC);

CREATE TABLE IF NOT EXISTS communication_sessions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  request_id UUID NOT NULL UNIQUE REFERENCES communication_requests(id) ON DELETE CASCADE,
  family_link_id UUID NOT NULL REFERENCES family_links(id) ON DELETE CASCADE,
  kind TEXT NOT NULL CHECK (kind IN ('audio_call','video_call','screen_share')),
  status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active','ended','expired')),
  started_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  ended_at TIMESTAMPTZ,
  ended_by UUID REFERENCES users(id)
);
CREATE INDEX IF NOT EXISTS idx_comm_sessions_family_active
  ON communication_sessions(family_link_id, status);

CREATE TABLE IF NOT EXISTS session_consent_events (
  id BIGSERIAL PRIMARY KEY,
  session_id UUID NOT NULL REFERENCES communication_sessions(id) ON DELETE CASCADE,
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  action TEXT NOT NULL CHECK (action IN ('accepted','rejected','started_local_capture','stopped_local_capture','ended')),
  occurred_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS device_permission_status (
  id BIGSERIAL PRIMARY KEY,
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  device_installation_id TEXT NOT NULL,
  permission_name TEXT NOT NULL CHECK (
    permission_name IN ('location_foreground','location_background','notifications','camera','microphone','screen_broadcast')
  ),
  status TEXT NOT NULL CHECK (status IN ('granted','denied','restricted','not_determined')),
  checked_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE(user_id, device_installation_id, permission_name)
);
