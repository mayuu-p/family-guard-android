# Linux VPS deployment (Ubuntu 22.04/24.04)

## 1. Provision
Use a supported Ubuntu VPS, a domain, SSH keys, firewall rules, and a non-root deploy
user. Allow inbound 22 (restricted to your IP), 80 and 443. Do not expose PostgreSQL
(5432) publicly.

## 2. Install runtime
```bash
sudo apt update
sudo apt install -y nodejs npm postgresql postgresql-contrib nginx certbot python3-certbot-nginx
node --version
```
Use a currently supported Node.js LTS release from the official NodeSource instructions
if Ubuntu's packaged Node version is too old.

## 3. PostgreSQL
```bash
sudo -u postgres psql
```
Then:
```sql
CREATE USER family_app WITH PASSWORD 'USE_A_LONG_RANDOM_PASSWORD';
CREATE DATABASE family_safety OWNER family_app;
\\q
```
Run `database/schema.sql` as the app database user. Keep database access local/private.

## 4. Backend
Copy `backend/` to `/opt/family-safety/backend`, create `.env` with production secrets:
```env
NODE_ENV=production
PORT=3000
DATABASE_URL=postgresql://family_app:STRONG_PASSWORD@127.0.0.1:5432/family_safety
DATABASE_SSL=false
JWT_SECRET=GENERATE_A_LONG_RANDOM_SECRET
JWT_EXPIRES_IN=2h
CORS_ORIGIN=https://app.example.com
FIREBASE_SERVICE_ACCOUNT_PATH=/etc/family-safety/firebase-service-account.json
```
Protect `.env` and the Firebase key:
```bash
sudo chown -R family-safety:family-safety /opt/family-safety
sudo chmod 600 /opt/family-safety/backend/.env /etc/family-safety/firebase-service-account.json
cd /opt/family-safety/backend
npm ci --omit=dev
```

## 5. systemd
Create `/etc/systemd/system/family-safety.service`:
```ini
[Unit]
Description=Family Safety API
After=network.target postgresql.service

[Service]
Type=simple
User=family-safety
WorkingDirectory=/opt/family-safety/backend
Environment=NODE_ENV=production
ExecStart=/usr/bin/node /opt/family-safety/backend/server.js
Restart=always
RestartSec=5
NoNewPrivileges=true
PrivateTmp=true
ProtectSystem=strict
ProtectHome=true

[Install]
WantedBy=multi-user.target
```
```bash
sudo systemctl daemon-reload
sudo systemctl enable --now family-safety
sudo journalctl -u family-safety -f
```

## 6. Nginx + TLS
Create `/etc/nginx/sites-available/family-safety`:
```nginx
server {
  listen 80;
  server_name api.example.com;
  location / {
    proxy_pass http://127.0.0.1:3000;
    proxy_http_version 1.1;
    proxy_set_header Host $host;
    proxy_set_header X-Real-IP $remote_addr;
    proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
    proxy_set_header X-Forwarded-Proto $scheme;
  }
}
```
Enable and issue certificate:
```bash
sudo ln -s /etc/nginx/sites-available/family-safety /etc/nginx/sites-enabled/
sudo nginx -t && sudo systemctl reload nginx
sudo certbot --nginx -d api.example.com
```

## 7. Before production launch
- Set `CORS_ORIGIN` to exact trusted origins; mobile CORS is not a security boundary.
- Add refresh-token rotation, account recovery, email verification and session revocation.
- Add FCM token registration from the app (the backend endpoint exists).
- Implement a proper visible Android foreground service and iOS background location.
- Add push notification permission UX and FCM client integration.
- Add audit logs, retention/deletion jobs, encrypted backups, restore drills and alerting.
- Add geofence hysteresis / consecutive-fix confirmation to reduce GPS boundary flapping.
- Add request validation, per-user rate limits, abuse monitoring and dependency scanning.
- Configure database TLS if using a managed remote database.
- Perform penetration testing and privacy/legal review for the jurisdictions where deployed.
